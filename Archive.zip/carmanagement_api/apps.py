from django.apps import AppConfig


class CarmanagementApiConfig(AppConfig):
    name = 'carmanagement_api'
